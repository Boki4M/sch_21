#include "m2.h"


void m2_f1()
{
    printf("TEST M2");
}

